close all;
% % % %%2D trajectory
% figure(1);           
% plot(out.xd,out.yd,'r',out.ETA1(:,1),out.ETA1(:,2),'b',out.ETA(:,1),out.ETA(:,2),'--g','linewidth',1.35);
% legend('Target trajectory','PPAFTC','SMAFTC');
% title('Two-dimensional locus');
% xlabel('X(m)');
% ylabel('Y(m)');
% axis tight;
% 
% f2=axes('position',[0.26,0.3,0.3,0.25]);    
% axis(f2);
% plot(out.xd,out.yd,'r',out.ETA1(:,1),out.ETA1(:,2),'b',out.ETA(:,1),out.ETA(:,2),'--g','linewidth',1.35);
% set(f2,'xlim',[-0.77474,-0.77462],'ylim',[0.6323,0.633]);
% set(f2,'xlim',[-0.8,-0.7],'ylim',[0.6,1]);

% 
% % % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% % %%3D trajectory
%
% figure(2);              
% plot3(out.re_position(:,1),out.re_position(:,2),out.re_position(:,3),'r',out.ETA1(:,1),out.ETA1(:,2),out.ETA1(:,3),...
% 'b',out.ETA(:,1),out.ETA(:,2),out.ETA(:,3),'--g','linewidth',1.35);
% text(1.5+0.1,1.5,1.5,'start position','Color','r')
% text(1.5,1.5,1,'\diamondsuit','color','r','HorizontalAlignment','center','FontSize',12,'FontWeigh','bold')
% text(out.ETA(10001,1),out.ETA(10001,2)+1,out.ETA(10001,3)+0.5,'end position','Color','b');
% text(out.ETA(10001,1),out.ETA(10001,2),out.ETA(10001,3),'\diamondsuit','color','b','HorizontalAlignment','center','FontSize',12,'FontWeigh','bold')
%  legend('Target trajectory','PPAFTC','SMAFTC');
% title('Three-dimensional trajectory');
% xlabel('X(m)');
% ylabel('Y(m)');
% zlabel('Z(m)');
% set(gca,'ZDir','reverse');        
% grid on;
% axis tight;
% 
% f3=axes('position',[0.68,0.1,0.3,0.22]);    
% axis(f3);
% plot3(out.re_position(:,1),out.re_position(:,2),out.re_position(:,3),'r',out.ETA1(:,1),out.ETA1(:,2),out.ETA1(:,3),...
% 'b',out.ETA(:,1),out.ETA(:,2),out.ETA(:,3),'--g','linewidth',1.35);
% grid on;
% set(f3,'xlim',[-0.95892,-0.95366],'ylim',[0.28,0.31],'zlim',[4.5,4.51]);

% 
% 
% % % % % % % % % % % %%
% % % % % % % % % % % % %

%%%Tracking errors of 6-DOF

% figure(1);      %Surge
% plot(out.t,out.r_max(:,1),'--g',out.t,-1*out.r_min(:,1),'--g','linewidth',1.15);
% hold on;
% plot(out.t,out.e_position1(:,1),'r',out.t,out.e_position(:,1),'b','linewidth',1.35);
% set(gca,'fontsize',15);
% title('Surge','FontSize',20);
% xlabel('time(s)','FontSize',20);
% ylabel('Error(m)','FontSize',20);
% axis tight;
% hold on;
% plot([25,25],[-0.1,1.6],'-.r');
% legend('Upper bound','Lower bound','PPAFTC','SMAFTC','t=25s','FontSize',12);
% hold on;
% set(gca,'LooseInset',[0,0,0,0]);         
% %%%%
% figure(2);      %Sway
% plot(out.t,out.r_max(:,2),'--g',out.t,-1*out.r_min(:,2),'--g','linewidth',1.15);
% hold on;
% plot(out.t,out.e_position1(:,2),'r',out.t,out.e_position(:,2),'b','linewidth',1.35);
% set(gca,'fontsize',15);
% title('Sway','fontsize',20);
% xlabel('time(s)','fontsize',20);
% ylabel('Error(m)','fontsize',20);
% axis tight;
% hold on;
% plot([25,25],[-0.05,0.6],'-.r');
% legend('Upper bound','Lower bound','PPAFTC','SMAFTC','t=25s','fontsize',12);
% hold on;
% set(gca,'LooseInset',[0,0,0,0]);        
% %%
% figure(3);      %Heave
% plot(out.t,out.r_max(:,3),'--g',out.t,-1*out.r_min(:,3),'--g','linewidth',1.15);
% hold on;
% plot(out.t,out.e_position1(:,3),'r',out.t,out.e_position(:,3),'b','linewidth',1.35);
% set(gca,'fontsize',15);
% title('Heave','fontsize',20);
% xlabel('time(s)','fontsize',20);
% ylabel('Error(m)','fontsize',20);
% axis tight;
% hold on;
% plot([25,25],[-1.1,0.1],'-.r');
% legend('Upper bound','Lower bound','PPAFTC','SMAFTC','t=25s','fontsize',12);
% hold on;
% set(gca,'LooseInset',[0,0,0,0]);       
% %%%%%
% figure(4);      %Roll
% plot(out.t,out.r_max(:,4),'--g',out.t,-1*out.r_min(:,4),'--g','linewidth',1.15);
% hold on;
% plot(out.t,out.e_position1(:,4),'r',out.t,out.e_position(:,4),'b','linewidth',1.35);
% set(gca,'fontsize',15);
% title('Roll','fontsize',20);
% xlabel('time(s)','fontsize',20);
% ylabel('Error(m)','fontsize',20);
% axis tight;
% hold on;
% plot([25,25],[-0.05,0.6],'-.r');
% legend('Upper bound','Lower bound','PPAFTC','SMAFTC','t=25s','fontsize',12);
% hold on;
% set(gca,'LooseInset',[0,0,0,0]);        
% % %%
% figure(5);      %Pitch
% plot(out.t,out.r_max(:,5),'--g',out.t,-1*out.r_min(:,5),'--g','linewidth',1.15);
% hold on;
% plot(out.t,out.e_position1(:,5),'r',out.t,out.e_position(:,5),'b','linewidth',1.35);
% set(gca,'fontsize',15);
% title('Pitch','fontsize',20);
% xlabel('time(s)','fontsize',20);
% ylabel('Error(m)','fontsize',20);
% axis tight;
% hold on;
% plot([25,25],[-0.36,0.05],'-.r');
% legend('Upper bound','Lower bound','PPAFTC','SMAFTC','t=25s','fontsize',12);
% hold on;
% set(gca,'LooseInset',[0,0,0,0]);         
% f2=axes('position',[0.6,0.28,0.35,0.22]);    
% axis(f2);
% plot(out.t,out.r_max(:,5),'--g',out.t,-1*out.r_min(:,5),'--g','linewidth',1.15);
% hold on;
% plot(out.t,out.e_position1(:,5),'r',out.t,out.e_position(:,5),'b','linewidth',1.35);
% set(gca,'fontsize',9);
% set(f2,'xlim',[23,35],'ylim',[-0.0075,0.05]);
% % %%
% figure(6);      %Yaw
% plot(out.t,out.r_max(:,6),'--g',out.t,-1*out.r_min(:,6),'--g','linewidth',1.15);
% hold on;
% plot(out.t,out.e_position1(:,6),'r',out.t,out.e_position(:,6),'b','linewidth',1.35);
% set(gca,'fontsize',15);
% title('Yaw','fontsize',20);
% xlabel('time(s)','fontsize',20);
% ylabel('Error(m)','fontsize',20);
% axis tight;
% hold on;
% plot([25,25],[-0.18,1.25],'-.r');
% legend('Upper bound','Lower bound','PPAFTC','SMAFTC','t=25s','fontsize',12);
% hold on;
% set(gca,'LooseInset',[0,0,0,0]);         
% f2=axes('position',[0.61,0.3,0.35,0.22]);    
% axis(f2);
% plot(out.t,out.r_max(:,6),'--g',out.t,-1*out.r_min(:,6),'--g','linewidth',1.15);
% hold on;
% plot(out.t,out.e_position1(:,6),'r',out.t,out.e_position(:,6),'b','linewidth',1.35);
% set(gca,'fontsize',9);
% set(f2,'xlim',[23,35],'ylim',[-0.15,0.03]);
% % % % % 


% % % %%
% % % % %%

% 
% 
% % % % % % % % Estimated and actual values
%
%
% figure(1);            %surge
% plot(out.t,out.f_act1(:,1),'r',out.t,out.f_hat1(:,1),'--b','linewidth',1.35);
% set(gca,'fontsize',15);
% legend('Failure','Estimated value','fontsize',12);
% title('Surge','fontsize',20);
% xlabel('time(s)','fontsize',20);
% ylabel('F(N)','fontsize',20);
% axis tight;
% set(gca,'LooseInset',[0,0,0,0]);         
% figure(2);            %Sway
% plot(out.t,out.f_act1(:,2),'r',out.t,out.f_hat1(:,2),'--b','linewidth',1.35);
% set(gca,'fontsize',15);
% legend('Failure','Estimated value','fontsize',12);
% title('Sway','fontsize',20);
% xlabel('time(s)','fontsize',20);
% ylabel('F(N)','fontsize',20);
% axis tight;
% set(gca,'LooseInset',[0,0,0,0]);         
% figure(3);            %Heave
% plot(out.t,out.f_act1(:,3),'r',out.t,out.f_hat1(:,3),'--b','linewidth',1.35);
% set(gca,'fontsize',15);
% legend('Failure','Estimated value','fontsize',12);
% title('Heave','fontsize',20);
% xlabel('time(s)','fontsize',20);
% ylabel('F(N)','fontsize',20);
% axis tight;
% set(gca,'LooseInset',[0,0,0,0]);         
% figure(4);            %Roll
% plot(out.t,out.f_act1(:,4),'r',out.t,out.f_hat1(:,4),'--b','linewidth',1.35);
% set(gca,'fontsize',15);
% legend('Failure','Estimated value','fontsize',12);
% title('Roll','fontsize',20);
% xlabel('time(s)','fontsize',20);
% ylabel('F(N)','fontsize',20);
% axis tight;
% set(gca,'LooseInset',[0,0,0,0]);         
% figure(5);            %Pitch
% plot(out.t,out.f_act1(:,5),'r',out.t,out.f_hat1(:,5),'--b','linewidth',1.35);
% set(gca,'fontsize',15);
% legend('Failure','Estimated value','fontsize',12);
% title('Pitch','fontsize',20);
% xlabel('time(s)','fontsize',20);
% ylabel('F(N)','fontsize',20);
% axis tight;
% set(gca,'LooseInset',[0,0,0,0]);         
% figure(6);            %Yaw
% plot(out.t,out.f_act1(:,6),'r',out.t,out.f_hat1(:,6),'--b','linewidth',1.35);
% set(gca,'fontsize',15);
% legend('Failure','Estimated value','fontsize',12);
% title('Yaw','fontsize',20);
% xlabel('time(s)','fontsize',20);
% ylabel('F(N)','fontsize',20);
% axis tight;
% set(gca,'LooseInset',[0,0,0,0]);         
% % 


% %%%%%%% 
% 
% % % % % % % % % % % 
% % % % % 
% % 
% 
% % % %% Thrusts of PPAFTC
% % 
% figure(1);        
% plot(out.t,out.ue1(:,1),'b','linewidth',1.35);
% title('u1');
% xlabel('time(s)');
% ylabel('F(N)');
% axis tight;
% figure(2);          %2
% plot(out.t,out.ue1(:,2),'b','linewidth',1.35);
% title('u2');
% xlabel('time(s)');
% ylabel('F(N)');
% axis tight;
% figure(3);          %3
% plot(out.t,out.ue1(:,3),'b','linewidth',1.35);
% title('u3');
% xlabel('time(s)');
% ylabel('F(N)');
% axis tight;
% figure(4);          %4
% plot(out.t,out.ue1(:,4),'b','linewidth',1.35);
% title('u4');
% xlabel('time(s)');
% ylabel('F(N)');
% axis tight;
% figure(5);          %5
% plot(out.t,out.ue1(:,5),'b','linewidth',1.35);
% title('u5');
% xlabel('time(s)');
% ylabel('F(N)');
% axis tight;
% figure(6);          %6
% plot(out.t,out.ue1(:,6),'b','linewidth',1.35);
% title('u6');
% xlabel('time(s)');
% ylabel('F(N)');
% axis tight;
% figure(7);          %7
% plot(out.t,out.ue1(:,7),'b','linewidth',1.35);
% title('u7');
% xlabel('time(s)');
% ylabel('F(N)');
% axis tight;
% figure(8);          %8
% plot(out.t,out.ue1(:,8),'b','linewidth',1.35);
% title('u8');
% xlabel('time(s)');
% ylabel('F(N)');
% axis tight;
% % 

% 
% 



% % 
%
%%% Thrusts of SMAFTC
%
%  %
% figure(1);        
% plot(out.t,out.ue0(:,1),'b','linewidth',1.35);
% title('u1');
% xlabel('time(s)');
% ylabel('F(N)');
% axis tight;
% figure(2);          %2
% plot(out.t,out.ue0(:,2),'b','linewidth',1.35);
% title('u2');
% xlabel('time(s)');
% ylabel('F(N)');
% axis tight;
% figure(3);          %3
% plot(out.t,out.ue0(:,3),'b','linewidth',1.35);
% title('u3');
% xlabel('time(s)');
% ylabel('F(N)');
% axis tight;
% figure(4);          %4
% plot(out.t,out.ue0(:,4),'b','linewidth',1.35);
% title('u4');
% xlabel('time(s)');
% ylabel('F(N)');
% axis tight;
% figure(5);          %5
% plot(out.t,out.ue0(:,5),'b','linewidth',1.35);
% title('u5');
% xlabel('time(s)');
% ylabel('F(N)');
% axis tight;
% figure(6);          %6
% plot(out.t,out.ue0(:,6),'b','linewidth',1.35);
% title('u6');
% xlabel('time(s)');
% ylabel('F(N)');
% axis tight;
% figure(7);          %7
% plot(out.t,out.ue0(:,7),'b','linewidth',1.35);
% title('u7');
% xlabel('time(s)');
% ylabel('F(N)');
% axis tight;
% figure(8);          %8
% plot(out.t,out.ue0(:,8),'b','linewidth',1.35);
% title('u8');
% xlabel('time(s)');
% ylabel('F(N)');
% axis tight;
% % % 
% 
% 
% 
