"ftc.slx" is the simulink file
"newpicture" is used to plot
Other files are related and used "S-function" files.

Please pay attention to path settings and version compatibility  before testing

By actual testing, this simulation project can run on MATLAB 2024a.