

function [sys,x0,str,ts,simStateCompliance] = Fault_observer(t,x,u,flag)

switch flag,

  %%%%%%%%%%%%%%%%%%
  % Initialization %
  %%%%%%%%%%%%%%%%%%
  case 0,
    [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes;

  %%%%%%%%%%%%%%%
  % Derivatives %
  %%%%%%%%%%%%%%%
  case 1,
    sys=mdlDerivatives(t,x,u);

  %%%%%%%%%%
  % Update %
  %%%%%%%%%%
  case 2,
    sys=mdlUpdate(t,x,u);

  %%%%%%%%%%%
  % Outputs %
  %%%%%%%%%%%
  case 3,
    sys=mdlOutputs(t,x,u);

  %%%%%%%%%%%%%%%%%%%%%%%
  % GetTimeOfNextVarHit %
  %%%%%%%%%%%%%%%%%%%%%%%
  case 4,
    sys=mdlGetTimeOfNextVarHit(t,x,u);

  %%%%%%%%%%%%%
  % Terminate %
  %%%%%%%%%%%%%
  case 9,
    sys=mdlTerminate(t,x,u);

  %%%%%%%%%%%%%%%%%%%%
  % Unexpected flags %
  %%%%%%%%%%%%%%%%%%%%
  otherwise
    DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));

end

% end sfuntmpl

 
function [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes

sizes = simsizes;
sizes.NumContStates  =12;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 12;         %falut_hat v_hat
sizes.NumInputs      = 18;         %[6 6 6]
sizes.DirFeedthrough = 1 ;          %
sizes.NumSampleTimes = 1;   % at least one sample time is needed

sys = simsizes(sizes);

%                                                                                                                                                                                    
% initialize the initial conditions
% 
x0  = [0 0 0 0 0 0 0 0 0 0 0 0];  %12
%
% str is always an empty matrix
%
str = [];

%
% initialize the array of sample times
%
ts  = [0 0];

% Specify the block simStateCompliance. The allowed values are:
%    'UnknownSimState', < The default setting; warn and assume DefaultSimState
%    'DefaultSimState', < Same sim state as a built-in block
%    'HasNoSimState',   < No sim state
%    'DisallowSimState' < Error out when saving or restoring the model sim state
simStateCompliance = 'UnknownSimState';

% end mdlInitializeSizes

%
%=============================================================================
% mdlDerivatives
% Return the derivatives for the continuous states.
%=============================================================================
%
function sys=mdlDerivatives(t,x,u)
%%
%
TAO=[u(1);u(2);u(3);u(4);u(5);u(6)];        %input
vu=u(7);vv=u(8);vw=u(9);vp=u(10);vq=u(11);vr=u(12);
xx=u(13);yy=u(14);zz=u(15);fai=u(16);theta=u(17);psi=u(18);
VV=[vu;vv;vw;vp;vq;vr];                     %v_eta
%%
%
m=125;          
Zg=0.05;         
r=0.31;          
density_w=1000;  
density_uuv=965; 
g=9.81;          
dt1=148;         
dt2=100;         
d1=280;          
d2=230;          
Iz=(8/15)*pi*density_uuv*r^5; Ix=(8/15)*pi*density_uuv*r^5;   Iy=(8/15)*pi*density_uuv*r^5;  I=(8/15)*pi*density_uuv*r^5; 

%%%%%%%%%%
Mrb=[m 0 0 0 m*Zg 0;0 m 0 -m*Zg 0 0;0 0 m 0 0 0;0 -m*Zg 0 Ix 0 0;m*Zg 0 0 0 Iy 0;0 0 0 0 0 Iz];                                                            
Ma=[(2/3)*pi*density_w*r^3 0 0 0 0 0;0 (2/3)*pi*density_w*r^3  0 0 0 0;0 0 (2/3)*pi*density_w*r^3  0 0 0;0 0 0 0 0 0;0 0 0 0 0 0;0 0 0 0 0 0];             
Crb=[0 0 0 m*Zg*vr m*vw -m*vv;0 0 0 -m*vw m*Zg*vr m*vu;0 0 0 m*(vv-Zg*vp) -m*(vu+Zg*vq) 0;
    -m*Zg*vr m*vw -m*(vv-Zg*vp) 0 I*vr -I*vq;-m*vw -m*Zg*vr m*(vu+Zg*vq) -I*vr 0 I*vp;m*vv -m*vu 0 I*vq -I*vp 0];                                          
Ca=[0 0 0 0 m*vw -m*vv;0 0 0 -m*vw 0 m*vu;0 0 0 m*vv -m*vu 0;0 m*vw -m*vv 0 0 0;-m*vw 0 m*vu 0 0 0;m*vv -m*vu 0 0 0 0];                                    
D=[dt1*abs(vu)+dt2 0 0 0 0 0;0 dt1*abs(vv)+dt2 0 0 0 0;0 0 dt1*abs(vw)+dt2 0 0 0;0 0 0 d1*abs(vp)+d2 0 0;0 0 0 0 d1*abs(vq)+d2 0;0 0 0 0 0 d1*abs(vr)+d2]; 
G=[(m*g-(4/3)*pi*r^3*density_w*g)*sin(theta);-(m*g-(4/3)*pi*r^3*density_w*g)*cos(theta)*sin(fai);-(m*g-(4/3)*pi*r^3*density_w*g)*cos(theta)*cos(fai);
    Zg*m*g*cos(theta)*sin(fai);Zg*m*g*sin(theta);0];                                                                                                
M=Mrb+Ma;C0=Crb+Ca;D0=D;G0=G;          
%%
%observer
V_hat=[x(1);x(2);x(3);x(4);x(5);x(6)];   %v_hat state
Crb_hat=[0 0 0 m*Zg*x(6) m*x(3) -m*x(2);0 0 0 -m*x(3) m*Zg*x(6) m*x(1);0 0 0 m*(x(2)-Zg*x(4)) -m*(x(1)+Zg*x(5)) 0;...
    -m*Zg*x(6) m*x(3) -m*(x(2)-Zg*x(4)) 0 I*x(6) -I*x(5);-m*x(3) -m*Zg*x(6) m*(x(1)+Zg*x(5)) -I*x(6) 0 I*x(4);m*x(2) -m*x(1) 0 I*x(5) -I*x(4) 0];   
Ca_hat=[0 0 0 0 m*x(3) -m*x(2);0 0 0 -m*x(3) 0 m*x(1);0 0 0 m*x(2) -m*x(1) 0;...
    0 m*x(3) -m*x(2) 0 0 0;-m*x(3) 0 m*x(1) 0 0 0;m*x(2) -m*x(1) 0 0 0 0];  
C0_hat=Crb_hat+Ca_hat;
D0_hat=[dt1*abs(x(1))+dt2 0 0 0 0 0;0 dt1*abs(x(2))+dt2 0 0 0 0;0 0 dt1*abs(x(3))+dt2 0 0 0;0 0 0 d1*abs(x(4))+d2 0 0;0 0 0 0 d1*abs(x(5))+d2 0;0 0 0 0 0 d1*abs(x(6))+d2];  
A_hat=C0_hat*V_hat+D0_hat*V_hat+G0;
W_hat=[x(7);x(8);x(9);x(10);x(11);x(12)];     %w_hat auxiliary state
e_v=(VV-V_hat);                 
%

% % D and L get from LMI


%%D 
D_gain=[3.83473114661286	0	0	0	-0.114189510435019	0;
0	3.83473114661286	0	0.114189510435019	0	0;
0	0	3.82879782238605	0	0	0;
0	0.114189510435019	0	7.17390930593125	0	0;
-0.114189510435019	0	0	0	7.17390930593125	0;
0	0	0	0	0	7.16982121134258];



%%L 


L=[732.101610237119	0	0	0	22.4167108446488	0;
0	732.101610237119	0	27.9511088040986	0	0;
0	0	730.579651886480	0	0	0;
0	-33.4530569376930	0	651.656458263831	0	0;
-16.9147627110545	0	0	0	651.656458263832	0;
0	0	0	0	0	651.609369974132];


%f
f_hat=D_gain*W_hat+D_gain*M*V_hat;                 %falut_hat
%%
sys(1)=[1 0 0 0 0 0]*(pinv(M)*(TAO+f_hat-A_hat+L*e_v));    %vel_hat
sys(2)=[0 1 0 0 0 0]*(pinv(M)*(TAO+f_hat-A_hat+L*e_v));  
sys(3)=[0 0 1 0 0 0]*(pinv(M)*(TAO+f_hat-A_hat+L*e_v));  
sys(4)=[0 0 0 1 0 0]*(pinv(M)*(TAO+f_hat-A_hat+L*e_v));              
sys(5)=[0 0 0 0 1 0]*(pinv(M)*(TAO+f_hat-A_hat+L*e_v));  
sys(6)=[0 0 0 0 0 1]*(pinv(M)*(TAO+f_hat-A_hat+L*e_v));  

% 
sys(7)=[1 0 0 0 0 0]*(-D_gain*W_hat-(TAO+D_gain*M*V_hat-A_hat));    %w_hat
sys(8)=[0 1 0 0 0 0]*(-D_gain*W_hat-(TAO+D_gain*M*V_hat-A_hat));       
sys(9)=[0 0 1 0 0 0]*(-D_gain*W_hat-(TAO+D_gain*M*V_hat-A_hat));       
sys(10)=[0 0 0 1 0 0]*(-D_gain*W_hat-(TAO+D_gain*M*V_hat-A_hat));                         
sys(11)=[0 0 0 0 1 0]*(-D_gain*W_hat-(TAO+D_gain*M*V_hat-A_hat));       
sys(12)=[0 0 0 0 0 1]*(-D_gain*W_hat-(TAO+D_gain*M*V_hat-A_hat));



% end mdlDerivatives
%
%=============================================================================
% mdlUpdate
% Handle discrete state updates, sample time hits, and major time step
% requirements.
%=============================================================================
%
function sys=mdlUpdate(t,x,u)

sys = [];

% end mdlUpdate

%
%=============================================================================
% mdlOutputs
% Return the block outputs.
%=============================================================================
%
function sys=mdlOutputs(t,x,u)
vu=u(7);vv=u(8);vw=u(9);vp=u(10);vq=u(11);vr=u(12);
VV=[vu;vv;vw;vp;vq;vr];      

%  D original
D_gain=[3.83473114661286	0	0	0	-0.114189510435019	0;
0	3.83473114661286	0	0.114189510435019	0	0;
0	0	3.82879782238605	0	0	0;
0	0.114189510435019	0	7.17390930593125	0	0;
-0.114189510435019	0	0	0	7.17390930593125	0;
0	0	0	0	0	7.16982121134258];


m=125;             
Zg=0.05;         
r=0.31;          
density_w=1000;  
density_uuv=965; 
Iz=(8/15)*pi*density_uuv*r^5; Ix=(8/15)*pi*density_uuv*r^5;   Iy=(8/15)*pi*density_uuv*r^5; 

%
Mrb=[m 0 0 0 m*Zg 0;0 m 0 -m*Zg 0 0;0 0 m 0 0 0;0 -m*Zg 0 Ix 0 0;m*Zg 0 0 0 Iy 0;0 0 0 0 0 Iz];         
Ma=[(2/3)*pi*density_w*r^3 0 0 0 0 0;0 (2/3)*pi*density_w*r^3  0 0 0 0;0 0 (2/3)*pi*density_w*r^3  0 0 0;...
    0 0 0 0 0 0;0 0 0 0 0 0;0 0 0 0 0 0];              
M=Mrb+Ma;
V_hat=[x(1);x(2);x(3);x(4);x(5);x(6)]; 
W_hat=[x(7);x(8);x(9);x(10);x(11);x(12)]; 



f_hat=D_gain*W_hat+D_gain*M*V_hat; 

V_error=VV-V_hat;
sys = [f_hat;V_error];    



% end mdlOutputs

%
%=============================================================================
% mdlGetTimeOfNextVarHit
% Return the time of the next hit for this block.  Note that the result is
% absolute time.  Note that this function is only used when you specify a
% variable discrete-time sample time [-2 0] in the sample time array in
% mdlInitializeSizes.
%=============================================================================
%
function sys=mdlGetTimeOfNextVarHit(t,x,u)

sampleTime =1 ;    %  Example, set the next hit to be one second later.
sys = t + sampleTime;


% end mdlGetTimeOfNextVarHit

%
%=============================================================================
% mdlTerminate
% Perform any end of simulation tasks.
%=============================================================================
%
function sys=mdlTerminate(t,x,u)

sys = [];

% end mdlTerminate
