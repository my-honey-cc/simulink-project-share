
function [sys,x0,str,ts,simStateCompliance] = ad_law(t,x,u,flag)

switch flag,

  %%%%%%%%%%%%%%%%%%
  % Initialization %
  %%%%%%%%%%%%%%%%%%
  case 0,
    [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes;

  %%%%%%%%%%%%%%%
  % Derivatives %
  %%%%%%%%%%%%%%%
  case 1,
    sys=mdlDerivatives(t,x,u);

  %%%%%%%%%%
  % Update %
  %%%%%%%%%%
  case 2,
    sys=mdlUpdate(t,x,u);

  %%%%%%%%%%%
  % Outputs %
  %%%%%%%%%%%
  case 3,
    sys=mdlOutputs(t,x,u);

  %%%%%%%%%%%%%%%%%%%%%%%
  % GetTimeOfNextVarHit %
  %%%%%%%%%%%%%%%%%%%%%%%
  case 4,
    sys=mdlGetTimeOfNextVarHit(t,x,u);

  %%%%%%%%%%%%%
  % Terminate %
  %%%%%%%%%%%%%
  case 9,
    sys=mdlTerminate(t,x,u);

  %%%%%%%%%%%%%%%%%%%%
  % Unexpected flags %
  %%%%%%%%%%%%%%%%%%%%
  otherwise
    DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));

end

% end sfuntmpl

 
function [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes

sizes = simsizes;
sizes.NumContStates  = 1;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 1;         %m
sizes.NumInputs      = 24;          %[6 6 6 6]
sizes.DirFeedthrough = 0;          %0
sizes.NumSampleTimes = 1;   % at least one sample time is needed 

sys = simsizes(sizes);

%
% initialize the initial conditions
%
x0  =0;    %1


%
% str is always an empty matrix
%
str = [];

%
% initialize the array of sample times
%
ts  = [0 0];

% Specify the block simStateCompliance. The allowed values are:
%    'UnknownSimState', < The default setting; warn and assume DefaultSimState
%    'DefaultSimState', < Same sim state as a built-in block
%    'HasNoSimState',   < No sim state
%    'DisallowSimState' < Error out when saving or restoring the model sim state
simStateCompliance = 'UnknownSimState';

% end mdlInitializeSizes

%
%=============================================================================
% mdlDerivatives
% Return the derivatives for the continuous states.
%=============================================================================
%
function sys=mdlDerivatives(t,x,u)
%%
m=125;              
Zg=0.05;         
r=0.31;          
density_w=1000;  
density_uuv=965; 
Iz=(8/15)*pi*density_uuv*r^5; Ix=(8/15)*pi*density_uuv*r^5;Iy=(8/15)*pi*density_uuv*r^5;I=(8/15)*pi*density_uuv*r^5; 

%%
%
xd=u(1);yd=u(2);zd=u(3);faid=u(4);thetad=u(5);psid=u(6);      
ETAD=[xd;yd;zd;faid;thetad;psid];
dxd=u(7);dyd=u(8);dzd=u(9);dfaid=u(10);dthetad=u(11);dpsid=u(12);    
dETAD=[dxd;dyd;dzd;dfaid;dthetad;dpsid];  
xp=u(13);yp=u(14);zp=u(15);fai=u(16);theta=u(17);psi=u(18);   
vu=u(19);vv=u(20);vw=u(21);vp=u(22);vq=u(23);vr=u(24);        
ETA=[xp;yp;zp;fai;theta;psi];                                 
V=[vu;vv;vw;vp;vq;vr];                                        

%%
c1=cos(fai);c2=cos(theta);c3=cos(psi);
s1=sin(fai);s2=sin(theta);s3=sin(psi);
t2=tan(theta);
J = [c3*c2 c3*s2*s1-s3*c1 c3*s2*c1+s3*s1 0 0 0;
     s3*c2 s3*s2*s1+c3*c1 s3*s2*c1-c3*s1 0 0 0;
     -s2 c2*s1 c2*c1 0 0 0;
     0 0 0 1 s1*t2 c1*t2;
     0 0 0 0 c1 -s1;
     0 0 0 0 s1/c2 c1/c2];
 dETA=J*V;             
 JT=J';
%%
Mrb=[m 0 0 0 m*Zg 0;0 m 0 -m*Zg 0 0;0 0 m 0 0 0;0 -m*Zg 0 Ix 0 0;m*Zg 0 0 0 Iy 0;0 0 0 0 0 Iz];  
Ma=[(2/3)*pi*density_w*r^3 0 0 0 0 0;0 (2/3)*pi*density_w*r^3 0 0 0 0;...
    0 0 (2/3)*pi*density_w*r^3  0 0 0;0 0 0 0 0 0;0 0 0 0 0 0;0 0 0 0 0 0];              
M=Mrb+Ma;
M_eta=pinv(JT)*M*pinv(J);         
E_eta=ETA-ETAD;              
%
K1=0.75;
V_control=dETAD-K1*E_eta;                     

S=dETA-V_control;                    
XX=pinv(M_eta')*S;
%omega
Q=1+norm(dETA)+norm(dETA)*norm(V)+(norm(dETA))^2;
%c1 c2
c1=0.5;c2=0.5;

m=x;
%%
sys=(c1*Q*(norm(XX)))-c2*m;
 

% end mdlDerivatives
%
%=============================================================================
% mdlUpdate
% Handle discrete state updates, sample time hits, and major time step
% requirements.
%=============================================================================
%
function sys=mdlUpdate(t,x,u)

sys = [];

% end mdlUpdate

%
%=============================================================================
% mdlOutputs
% Return the block outputs.
%=============================================================================
%
function sys=mdlOutputs(t,x,u)
 
sys = x;


% end mdlOutputs

%
%=============================================================================
% mdlGetTimeOfNextVarHit
% Return the time of the next hit for this block.  Note that the result is
% absolute time.  Note that this function is only used when you specify a
% variable discrete-time sample time [-2 0] in the sample time array in
% mdlInitializeSizes.
%=============================================================================
%
function sys=mdlGetTimeOfNextVarHit(t,x,u)

sampleTime =1 ;    %  Example, set the next hit to be one second later.
sys = t + sampleTime;


% end mdlGetTimeOfNextVarHit

%
%=============================================================================
% mdlTerminate
% Perform any end of simulation tasks.
%=============================================================================
%
function sys=mdlTerminate(t,x,u)

sys = [];

% end mdlTerminate
