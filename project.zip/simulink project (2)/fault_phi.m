
function [sys,x0,str,ts,simStateCompliance] = fault_phi(t,x,u,flag)

switch flag,

  %%%%%%%%%%%%%%%%%%
  % Initialization %
  %%%%%%%%%%%%%%%%%%
  case 0,
    [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes;

  %%%%%%%%%%%%%%%
  % Derivatives %
  %%%%%%%%%%%%%%%
  case 1,
    sys=mdlDerivatives(t,x,u);

  %%%%%%%%%%
  % Update %
  %%%%%%%%%%
  case 2,
    sys=mdlUpdate(t,x,u);

  %%%%%%%%%%%
  % Outputs %
  %%%%%%%%%%%
  case 3,
    sys=mdlOutputs(t,x,u);

  %%%%%%%%%%%%%%%%%%%%%%%
  % GetTimeOfNextVarHit %
  %%%%%%%%%%%%%%%%%%%%%%%
  case 4,
    sys=mdlGetTimeOfNextVarHit(t,x,u);

  %%%%%%%%%%%%%
  % Terminate %
  %%%%%%%%%%%%%
  case 9,
    sys=mdlTerminate(t,x,u);

  %%%%%%%%%%%%%%%%%%%%
  % Unexpected flags %
  %%%%%%%%%%%%%%%%%%%%
  otherwise
    DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));

end

% end sfuntmpl

 
function [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes

sizes = simsizes;
sizes.NumContStates  = 1;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 1;         %m
sizes.NumInputs      = 24;          %[6 6 6 6] etad, eta, veld, vel
sizes.DirFeedthrough = 0;          %0
sizes.NumSampleTimes = 1;   % at least one sample time is needed 

sys = simsizes(sizes);

%
% initialize the initial conditions
%
x0  =0;    %1


%
% str is always an empty matrix
%
str = [];

%
% initialize the array of sample times
%
ts  = [0 0];

% Specify the block simStateCompliance. The allowed values are:
%    'UnknownSimState', < The default setting; warn and assume DefaultSimState
%    'DefaultSimState', < Same sim state as a built-in block
%    'HasNoSimState',   < No sim state
%    'DisallowSimState' < Error out when saving or restoring the model sim state
simStateCompliance = 'UnknownSimState';

% end mdlInitializeSizes

%
%=============================================================================
% mdlDerivatives
% Return the derivatives for the continuous states.
%=============================================================================
%
function sys=mdlDerivatives(t,x,u)
%%%%pos-eta
%%ref-pos
xd=u(1);yd=u(2);zd=u(3);faid=u(4);thetad=u(5);psid=u(6);      %refer pos;
ETAD=[xd;yd;zd;faid;thetad;psid];
%%%%true-pos
xp=u(7);yp=u(8);zp=u(9);fai=u(10);theta=u(11);psi=u(12);   %pos
ETA=[xp;yp;zp;fai;theta;psi];  
%%ref-vel
dxd=u(13);dyd=u(14);dzd=u(15);dfaid=u(16);dthetad=u(17);dpsid=u(18);    %refer vel
dETAD=[dxd;dyd;dzd;dfaid;dthetad;dpsid];   
%%true-vel
vu=u(19);vv=u(20);vw=u(21);vp=u(22);vq=u(23);vr=u(24);        %vel
V=[vu;vv;vw;vp;vq;vr];
%%%deta
c1=cos(fai);c2=cos(theta);c5=cos(psi);
s1=sin(fai);s2=sin(theta);s3=sin(psi);
t2=tan(theta);
J = [c5*c2 c5*s2*s1-s3*c1 c5*s2*c1+s3*s1 0 0 0;
     s3*c2 s3*s2*s1+c5*c1 s3*s2*c1-c5*s1 0 0 0;
     -s2 c2*s1 c2*c1 0 0 0;
     0 0 0 1 s1*t2 c1*t2;
     0 0 0 0 c1 -s1;
     0 0 0 0 s1/c2 c1/c2];
deta=J*V;
%%%%%%s
k1=4*diag([15 20 20 60 60 200]);
ddelta_eta=dETAD-deta;
delta_eta=ETAD-ETA;
s=ddelta_eta+k1*delta_eta;

%%%%%phi
beta=0.1;
eps_u=20;
X=1;
sys=beta*norm(s)^2/(norm(s)+eps_u*exp(-X*t))-beta*x;


% end mdlDerivatives
%
%=============================================================================
% mdlUpdate
% Handle discrete state updates, sample time hits, and major time step
% requirements.
%=============================================================================
%
function sys=mdlUpdate(t,x,u)

sys = [];

% end mdlUpdate

%
%=============================================================================
% mdlOutputs
% Return the block outputs.
%=============================================================================
%
function sys=mdlOutputs(t,x,u)
 
sys = x;


% end mdlOutputs

%
%=============================================================================
% mdlGetTimeOfNextVarHit
% Return the time of the next hit for this block.  Note that the result is
% absolute time.  Note that this function is only used when you specify a
% variable discrete-time sample time [-2 0] in the sample time array in
% mdlInitializeSizes.
%=============================================================================
%
function sys=mdlGetTimeOfNextVarHit(t,x,u)

sampleTime =1 ;    %  Example, set the next hit to be one second later.
sys = t + sampleTime;


% end mdlGetTimeOfNextVarHit

%
%=============================================================================
% mdlTerminate
% Perform any end of simulation tasks.
%=============================================================================
%
function sys=mdlTerminate(t,x,u)

sys = [];

% end mdlTerminate
