


function [sys,x0,str,ts,simStateCompliance] = plant(t,x,u,flag)

switch flag,

  %%%%%%%%%%%%%%%%%%
  % Initialization %
  %%%%%%%%%%%%%%%%%%
  case 0,
    [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes;

  %%%%%%%%%%%%%%%
  % Derivatives %
  %%%%%%%%%%%%%%%
  case 1,
    sys=mdlDerivatives(t,x,u);

  %%%%%%%%%%
  % Update %
  %%%%%%%%%%
  case 2,
    sys=mdlUpdate(t,x,u);

  %%%%%%%%%%%
  % Outputs %
  %%%%%%%%%%%
  case 3,
    sys=mdlOutputs(t,x,u);

  %%%%%%%%%%%%%%%%%%%%%%%
  % GetTimeOfNextVarHit %
  %%%%%%%%%%%%%%%%%%%%%%%
  case 4,
    sys=mdlGetTimeOfNextVarHit(t,x,u);

  %%%%%%%%%%%%%
  % Terminate %
  %%%%%%%%%%%%%
  case 9,
    sys=mdlTerminate(t,x,u);

  %%%%%%%%%%%%%%%%%%%%
  % Unexpected flags %
  %%%%%%%%%%%%%%%%%%%%
  otherwise
    DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));

end

% end sfuntmpl

 
function [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes

sizes = simsizes;
sizes.NumContStates  = 12;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 12;         
sizes.NumInputs      = 8;         
sizes.DirFeedthrough = 0;          
sizes.NumSampleTimes = 1;   % at least one sample time is needed 

sys = simsizes(sizes);

%
% initialize the initial conditions
%

x0  = [0, -3, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0];

%

%
% str is always an empty matrix
%
str = [];

%
% initialize the array of sample times
%
ts  = [0 0];

% Specify the block simStateCompliance. The allowed values are:
%    'UnknownSimState', < The default setting; warn and assume DefaultSimState
%    'DefaultSimState', < Same sim state as a built-in block
%    'HasNoSimState',   < No sim state
%    'DisallowSimState' < Error out when saving or restoring the model sim state
simStateCompliance = 'UnknownSimState';

% end mdlInitializeSizes

%
%=============================================================================
% mdlDerivatives
% Return the derivatives for the continuous states.
%=============================================================================
%
function sys=mdlDerivatives(t,x,u)
%%
%ODIN parameter
m=125;           
Zg=0.05;         
r=0.31;          
density_w=1000;  
density_uuv=965; 
g=9.81;          
dt1=148;         
dt2=100;         
d1=280;          
d2=230;          
s=sin(pi/4);     
R=0.381;         
Rz=0.508;        
Iz=(8/15)*pi*density_uuv*r^5; Ix=(8/15)*pi*density_uuv*r^5;Iy=(8/15)*pi*density_uuv*r^5;I=(8/15)*pi*density_uuv*r^5; 

%%
%state
xp=x(1);yp=x(2);zp=x(3);fai=x(4);theta=x(5);psi=x(6);     % position
vu=x(7);vv=x(8);vw=x(9);vp=x(10);vq=x(11);vr=x(12);       %vel
V=[vu;vv;vw;vp;vq;vr];                                    %vel matrix
uu=[u(1);u(2);u(3);u(4);u(5);u(6);u(7);u(8)];             %8 thrusters input
B=[s -s -s s 0 0 0 0;s s -s -s 0 0 0 0;0 0 0 0 -1 -1 -1 -1;0 0 0 0 R*s R*s -R*s -R*s;0 0 0 0 R*s -R*s -R*s R*s;Rz -Rz Rz -Rz 0 0 0 0];      
TAO=B*uu;                                        %transfer
%%
%disturbance

TAOd1=0.2+0.3*sin(0.2*t);TAOd2=0.3+0.15*sin(0.3*t);TAOd3=0.4*sin(0.1*t);TAOd4=0.2+0.05*cos(0.1*t);
TAOd5=0.1+0.1*cos(0.2*t);TAOd6=0.2+0.2*cos(0.3*t);

TAO_d=[TAOd1;TAOd2;TAOd3;TAOd4;TAOd5;TAOd6];      

%%
%transfer
c1=cos(fai);c2=cos(theta);c3=cos(psi);
s1=sin(fai);s2=sin(theta);s3=sin(psi);
t2=tan(theta);
J = [c3*c2 c3*s2*s1-s3*c1 c3*s2*c1+s3*s1 0 0 0;
     s3*c2 s3*s2*s1+c3*c1 s3*s2*c1-c3*s1 0 0 0;
     -s2 c2*s1 c2*c1 0 0 0;
     0 0 0 1 s1*t2 c1*t2;
     0 0 0 0 c1 -s1;
     0 0 0 0 s1/c2 c1/c2];
%%
%
Mrb=[m 0 0 0 m*Zg 0;0 m 0 -m*Zg 0 0;0 0 m 0 0 0;0 -m*Zg 0 Ix 0 0;m*Zg 0 0 0 Iy 0;0 0 0 0 0 Iz];                                                            
Ma=[(2/3)*pi*density_w*r^3 0 0 0 0 0;0 (2/3)*pi*density_w*r^3  0 0 0 0;0 0 (2/3)*pi*density_w*r^3  0 0 0;0 0 0 0 0 0;0 0 0 0 0 0;0 0 0 0 0 0];             
Crb=[0 0 0 m*Zg*vr m*vw -m*vv;0 0 0 -m*vw m*Zg*vr m*vu;0 0 0 m*(vv-Zg*vp) -m*(vu+Zg*vq) 0;
    -m*Zg*vr m*vw -m*(vv-Zg*vp) 0 I*vr -I*vq;-m*vw -m*Zg*vr m*(vu+Zg*vq) -I*vr 0 I*vp;m*vv -m*vu 0 I*vq -I*vp 0];                                           
Ca=[0 0 0 0 m*vw -m*vv;0 0 0 -m*vw 0 m*vu;0 0 0 m*vv -m*vu 0;0 m*vw -m*vv 0 0 0;-m*vw 0 m*vu 0 0 0;m*vv -m*vu 0 0 0 0];                                     
D=[dt1*abs(vu)+dt2 0 0 0 0 0;0 dt1*abs(vv)+dt2 0 0 0 0;0 0 dt1*abs(vw)+dt2 0 0 0;0 0 0 d1*abs(vp)+d2 0 0;0 0 0 0 d1*abs(vq)+d2 0;0 0 0 0 0 d1*abs(vr)+d2];  
G=[(m*g-(4/3)*pi*r^3*density_w*g)*sin(theta);-(m*g-(4/3)*pi*r^3*density_w*g)*cos(theta)*sin(fai);-(m*g-(4/3)*pi*r^3*density_w*g)*cos(theta)*cos(fai);
    Zg*m*g*cos(theta)*sin(fai);Zg*m*g*sin(theta);0];   
M=Mrb+Ma;
C=Crb+Ca; 
F=TAO_d;

%%
sys(1)=[1 0 0 0 0 0]*J*V;        %pos_eta_dot=......
sys(2)=[0 1 0 0 0 0]*J*V;
sys(3)=[0 0 1 0 0 0]*J*V;
sys(4)=[0 0 0 1 0 0]*J*V;       
sys(5)=[0 0 0 0 1 0]*J*V;
sys(6)=[0 0 0 0 0 1]*J*V;

sys(7)=[1 0 0 0 0 0]*pinv(M)*(-C*V-D*V-G+F+TAO);     %v_eta_dot=......
sys(8)=[0 1 0 0 0 0]*pinv(M)*(-C*V-D*V-G+F+TAO); 
sys(9)=[0 0 1 0 0 0]*pinv(M)*(-C*V-D*V-G+F+TAO); 
sys(10)=[0 0 0 1 0 0]*pinv(M)*(-C*V-D*V-G+F+TAO);     
sys(11)=[0 0 0 0 1 0]*pinv(M)*(-C*V-D*V-G+F+TAO); 
sys(12)=[0 0 0 0 0 1]*pinv(M)*(-C*V-D*V-G+F+TAO); 

% end mdlDerivatives
%
%=============================================================================
% mdlUpdate
% Handle discrete state updates, sample time hits, and major time step
% requirements.
%=============================================================================
%
function sys=mdlUpdate(t,x,u)

sys = [];

% end mdlUpdate

%
%=============================================================================
% mdlOutputs
% Return the block outputs.
%=============================================================================
%
function sys=mdlOutputs(t,x,u)


sys = x;        

% end mdlOutputs

%
%=============================================================================
% mdlGetTimeOfNextVarHit
% Return the time of the next hit for this block.  Note that the result is
% absolute time.  Note that this function is only used when you specify a
% variable discrete-time sample time [-2 0] in the sample time array in
% mdlInitializeSizes.
%=============================================================================
%
function sys=mdlGetTimeOfNextVarHit(t,x,u)

sampleTime =1 ;    %  Example, set the next hit to be one second later.
sys = t + sampleTime;


% end mdlGetTimeOfNextVarHit

%
%=============================================================================
% mdlTerminate
% Perform any end of simulation tasks.
%=============================================================================
%
function sys=mdlTerminate(t,x,u)

sys = [];

% end mdlTerminate
