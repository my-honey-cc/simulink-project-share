close all;
clc;
% % % %%2D Trajectory
% figure(1);           
% plot(out.xd,out.yd,'r',out.ETA1(:,1),out.ETA1(:,2),'b',out.ETA2(:,1),out.ETA2(:,2),'--g','linewidth',1.35);
% text(0+0.1,-3-0.5,'start position','Color','r')
% text(0,-3,'\diamondsuit','color','r','HorizontalAlignment','center','FontSize',12,'FontWeigh','bold')
% legend('Target trajectory','PPAFTC','CPFTC');
% title('Two-dimensional locus');
% xlabel('X(m)');
% ylabel('Y(m)');
% axis tight;


% 
% % % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%3D
%
% 3D-Trajectory
%
% figure(2);              
% plot3(out.re_position(:,1),out.re_position(:,2),out.re_position(:,3),'r',out.ETA1(:,1),out.ETA1(:,2),out.ETA1(:,3),...
% 'b',out.ETA2(:,1),out.ETA2(:,2),out.ETA2(:,3),'--g','linewidth',1.35);
% text(0+0.1,-3-0.5,2,'start position','Color','r')
% text(0.1,-3,1,'\diamondsuit','color','r','HorizontalAlignment','center','FontSize',12,'FontWeigh','bold')
% text(out.ETA1(20001,1),out.ETA1(20001,2)+1,out.ETA1(20001,3)+0.5,'end position','Color','b');
% text(out.ETA1(20001,1),out.ETA1(20001,2),out.ETA1(20001,3),'\diamondsuit','color','b','HorizontalAlignment','center','FontSize',12,'FontWeigh','bold')
% legend('Target trajectory','PPAFTC','CPFTC');
% title('Three-dimensional trajectory');
% xlabel('X(m)');
% ylabel('Y(m)');
% zlabel('Z(m)');
% set(gca,'ZDir','reverse');        
% grid on;
% axis tight;
% %
% 
% 
% % % % % % % % % % % %%
% % % % % % % % % % % % %
%
%%Tracking error of 6-DOF
%
%
% figure(1);      %Surge
% plot(out.t,out.r_max(:,1),'--g',out.t,-1*out.r_min(:,1),'--g','linewidth',1.15);
% hold on;
% plot(out.t,out.e_position1(:,1),'r',out.t,out.e_position2(:,1),'b','linewidth',1.35);
% set(gca,'fontsize',15);
% title('Surge','FontSize',20);
% xlabel('time(s)','FontSize',20);
% ylabel('Error(m)','FontSize',20);
% axis tight;
% hold on;
% plot([25,25],[-0.1,1.6],'-.r');
% legend('Upper bound','Lower bound','PPAFTC','CPFTC','t=25s','FontSize',12);
% hold on;
% set(gca,'LooseInset',[0,0,0,0]);        
% f2=axes('position',[0.6,0.2,0.35,0.22]); 
% axis(f2);
% plot(out.t,out.r_max(:,1),'--g',out.t,-1*out.r_min(:,1),'--g','linewidth',1.15);
% hold on;
% plot(out.t,out.e_position1(:,1),'r',out.t,out.e_position2(:,1),'b','linewidth',1.35);
% set(gca,'fontsize',9);
% set(f2,'xlim',[23,35],'ylim',[-0.15,0.03]);
% %%%%
% figure(2);      %Sway
% plot(out.t,out.r_max(:,2),'--g',out.t,-1*out.r_min(:,2),'--g','linewidth',1.15);
% hold on;
% plot(out.t,out.e_position1(:,2),'r',out.t,out.e_position2(:,2),'b','linewidth',1.35);
% set(gca,'fontsize',15);
% title('Sway','fontsize',20);
% xlabel('time(s)','fontsize',20);
% ylabel('Error(m)','fontsize',20);
% axis tight;
% hold on;
% plot([25,25],[-0.05,0.6],'-.r');
% legend('Upper bound','Lower bound','PPAFTC','CPFTC','t=25s','fontsize',12);
% hold on;
% set(gca,'LooseInset',[0,0,0,0]);         
% f2=axes('position',[0.61,0.3,0.35,0.22]);    
% axis(f2);
% plot(out.t,out.r_max(:,2),'--g',out.t,-1*out.r_min(:,2),'--g','linewidth',1.15);
% hold on;
% plot(out.t,out.e_position1(:,2),'r',out.t,out.e_position2(:,2),'b','linewidth',1.35);
% set(gca,'fontsize',9);
% set(f2,'xlim',[32,34],'ylim',[-0.02,0.02]);
% %%
% figure(3);      %Heave
% plot(out.t,out.r_max(:,3),'--g',out.t,-1*out.r_min(:,3),'--g','linewidth',1.15);
% hold on;
% plot(out.t,out.e_position1(:,3),'r',out.t,out.e_position2(:,3),'b','linewidth',1.35);
% set(gca,'fontsize',15);
% title('Heave','fontsize',20);
% xlabel('time(s)','fontsize',20);
% ylabel('Error(m)','fontsize',20);
% axis tight;
% hold on;
% plot([25,25],[-1.1,0.1],'-.r');
% legend('Upper bound','Lower bound','PPAFTC','CPFTC','t=25s','fontsize',12,'location','SouthEast');
% hold on;
% set(gca,'LooseInset',[0,0,0,0]);       
% %%%%%
% figure(4);      %Roll
% plot(out.t,out.r_max(:,4),'--g',out.t,-1*out.r_min(:,4),'--g','linewidth',1.15);
% hold on;
% plot(out.t,out.e_position1(:,4),'r',out.t,out.e_position2(:,4),'b','linewidth',1.35);
% set(gca,'fontsize',15);
% title('Roll','fontsize',20);
% xlabel('time(s)','fontsize',20);
% ylabel('Error(m)','fontsize',20);
% axis tight;
% hold on;
% plot([25,25],[-0.05,0.6],'-.r');
% legend('Upper bound','Lower bound','PPAFTC','CPFTC','t=25s','fontsize',12);
% hold on;
% set(gca,'LooseInset',[0,0,0,0]);        
% % %%
% figure(5);      %Pitch
% plot(out.t,out.r_max(:,5),'--g',out.t,-1*out.r_min(:,5),'--g','linewidth',1.15);
% hold on;
% plot(out.t,out.e_position1(:,5),'r',out.t,out.e_position2(:,5),'b','linewidth',1.35);
% set(gca,'fontsize',15);
% title('Pitch','fontsize',20);
% xlabel('time(s)','fontsize',20);
% ylabel('Error(m)','fontsize',20);
% axis tight;
% hold on;
% plot([25,25],[-0.36,0.05],'-.r');
% legend('Upper bound','Lower bound','PPAFTC','CPFTC','t=25s','fontsize',12,'location','SouthEast');
% hold on;
% set(gca,'LooseInset',[0,0,0,0]);  
% %%%%%%
% figure(6);      %Yaw
% plot(out.t,out.r_max(:,6),'--g',out.t,-1*out.r_min(:,6),'--g','linewidth',1.15);
% hold on;
% plot(out.t,out.e_position1(:,6),'r',out.t,out.e_position2(:,6),'b','linewidth',1.35);
% set(gca,'fontsize',15);
% title('Yaw','fontsize',20);
% xlabel('time(s)','fontsize',20);
% ylabel('Error(m)','fontsize',20);
% axis tight;
% hold on;
% plot([25,25],[-0.18,1.25],'-.r');
% legend('Upper bound','Lower bound','PPAFTC','CPFTC','t=25s','fontsize',12);
% hold on;
% set(gca,'LooseInset',[0,0,0,0]);  
% 
% 
