function [sys,x0,str,ts,simStateCompliance] = sigma1(t,x,u,flag)

%
% The following outlines the general structure of an S-function.
%
switch flag,

  %%%%%%%%%%%%%%%%%%
  % Initialization %
  %%%%%%%%%%%%%%%%%%
  case 0,
    [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes;

  %%%%%%%%%%%%%%%
  % Derivatives %
  %%%%%%%%%%%%%%%
  case 1,
    sys=mdlDerivatives(t,x,u);

  %%%%%%%%%%
  % Update %
  %%%%%%%%%%
  case 2,
    sys=mdlUpdate(t,x,u);

  %%%%%%%%%%%
  % Outputs %
  %%%%%%%%%%%
  case 3,
    sys=mdlOutputs(t,x,u);

  %%%%%%%%%%%%%%%%%%%%%%%
  % GetTimeOfNextVarHit %
  %%%%%%%%%%%%%%%%%%%%%%%
  case 4,
    sys=mdlGetTimeOfNextVarHit(t,x,u);

  %%%%%%%%%%%%%
  % Terminate %
  %%%%%%%%%%%%%
  case 9,
    sys=mdlTerminate(t,x,u);

  %%%%%%%%%%%%%%%%%%%%
  % Unexpected flags %
  %%%%%%%%%%%%%%%%%%%%
  otherwise
    DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));

end

% end sfuntmpl

%
%=============================================================================
% mdlInitializeSizes
% Return the sizes, initial conditions, and sample times for the S-function.
%=============================================================================
%
function [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes

%
% call simsizes for a sizes structure, fill it in and convert it to a
% sizes array.
%
% Note that in this example, the values are hard coded.  This is not a
% recommended practice as the characteristics of the block are typically
% defined by the S-function parameters.
%
sizes = simsizes;

sizes.NumContStates  = 8; 
sizes.NumDiscStates  = 0; 
sizes.NumOutputs     = 8; 
sizes.NumInputs      = 16; %[8 8]
sizes.DirFeedthrough = 0; 
sizes.NumSampleTimes = 1;   % at least one sample time is needed

sys = simsizes(sizes);

%
% initialize the initial conditions
%
x0  = [0 0 0 0 0 0 0 0];%8

%
% str is always an empty matrix
%
str = [];

%
% initialize the array of sample times
%
ts  = [0 0];

% Specify the block simStateCompliance. The allowed values are:
%    'UnknownSimState', < The default setting; warn and assume DefaultSimState
%    'DefaultSimState', < Same sim state as a built-in block
%    'HasNoSimState',   < No sim state
%    'DisallowSimState' < Error out when saving or restoring the model sim state
simStateCompliance = 'UnknownSimState';

% end mdlInitializeSizes

%
%=============================================================================
% mdlDerivatives
% Return the derivatives for the continuous states.
%=============================================================================
%
function sys=mdlDerivatives(t,x,u)


k=0.8*diag([100,100,85,90,90,90,80,80]);
ucmax=zeros(8,1);
for i=1:1:8
    ucmax(i)=150*k(i,i);
end
k_sigma=50;



%uv(u1-u8)
uc1=u(1);
uc2=u(2);
uc3=u(3);
uc4=u(4);
uc5=u(5);
uc6=u(6);
uc7=u(7);
uc8=u(8);

uc=[uc1;uc2;uc3;uc4;uc5;uc6;uc7;uc8];

uv1=u(9);
uv2=u(10);
uv3=u(11);
uv4=u(12);
uv5=u(13);
uv6=u(14);
uv7=u(15);
uv8=u(16);
uv=[uv1;uv2;uv3;uv4;uv5;uv6;uv7;uv8];


for i=1:1:8
    uvv(i)=uv(i)+uv(i)^3/ucmax(i)^2;
    guv(i)=ucmax(i)*(exp(uvv(i)/ucmax(i))-exp(-uv(i)/ucmax(i)))/(exp(uvv(i)/ucmax(i))+exp(-uv(i)/ucmax(i)));
    delta_uc(i)=guv(i)-uc(i);
end




    sigma=[x(1);x(2);x(3);x(4);x(5);x(6);x(7);x(8)]; 



sys(1)=-k_sigma*sigma(1)+delta_uc(1);
sys(2)=-k_sigma*sigma(2)+delta_uc(2);
sys(3)=-k_sigma*sigma(3)+delta_uc(3);
sys(4)=-k_sigma*sigma(4)+delta_uc(4);
sys(5)=-k_sigma*sigma(5)+delta_uc(5);
sys(6)=-k_sigma*sigma(6)+delta_uc(6);
sys(7)=-k_sigma*sigma(7)+delta_uc(7);
sys(8)=-k_sigma*sigma(8)+delta_uc(8);




% end mdlDerivatives

%
%=============================================================================
% mdlUpdate
% Handle discrete state updates, sample time hits, and major time step
% requirements.
%=============================================================================
%
function sys=mdlUpdate(t,x,u)

sys = [];

% end mdlUpdate

%
%=============================================================================
% mdlOutputs
% Return the block outputs.
%=============================================================================
%
function sys=mdlOutputs(t,x,u)

sys = x;

% end mdlOutputs

%
%=============================================================================
% mdlGetTimeOfNextVarHit
% Return the time of the next hit for this block.  Note that the result is
% absolute time.  Note that this function is only used when you specify a
% variable discrete-time sample time [-2 0] in the sample time array in
% mdlInitializeSizes.
%=============================================================================
%
function sys=mdlGetTimeOfNextVarHit(t,x,u)

sampleTime = 1;    %  Example, set the next hit to be one second later.
sys = t + sampleTime;

% end mdlGetTimeOfNextVarHit

%
%=============================================================================
% mdlTerminate
% Perform any end of simulation tasks.
%=============================================================================
%
function sys=mdlTerminate(t,x,u)

sys = [];

% end mdlTerminate
